<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Php Task</title>
</head>

<body>
    <div class="container" style="margin-left:20%">
        <form action="save_data.php" method="post">
            <input type="text" name="u_name" placeholder="Full Name"><br><br>
            <input type="tel" name="u_phone" placeholder="Phone Number"><br><br>
            <input type="email" name="u_email" placeholder="Email"><br><br>
            <input type="text" name="u_subject" placeholder="Subject"><br><br>
            <input type="text" name="u_msg" placeholder="Message"><br><br>
            <input type="submit" name="submit" value="submit" />
        </form>
    </div>
</body>

</html>