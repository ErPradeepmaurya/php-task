<?php
$servername = "localhost";
$username = "root";
$passsword = "";
$db_name = "php_data";

$conn = mysqli_connect($servername, $username, $passsword, $db_name);
if ($conn) {
    // echo 'success';
} else {
    // echo 'false';
}
if (isset($_GET['id']))
    $editeid = $_GET['id'];
// echo $editeid;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Php Task</title>
</head>

<body>
    <div class="container" style="margin-left:20%">
        <form action="save_data.php" method="post">
            <?php
            $query = mysqli_query($conn, "SELECT * FROM `employee` WHERE id = '$editeid' ");
            if (mysqli_num_rows($query) > 0)
                while ($data = mysqli_fetch_assoc($query)) {
            ?>
                <input type="hidden" name="editid" value="<?php echo $editeid; ?>"><br><br>
                <input type="text" name="u_name" value="<?= $data['u_name'] ?>"><br><br>
                <input type="tel" name="u_phone" value="<?= $data['u_phone'] ?>"><br><br>
                <input type="email" name="u_email" value="<?= $data['u_email'] ?>"><br><br>
                <input type="text" name="u_subject" value="<?= $data['u_subject'] ?>"><br><br>
                <input type="text" name="u_msg" value="<?= $data['u_message'] ?>"><br><br>
                <input type="submit" name="update_data" value="update" />
            <?php } ?>
        </form>
    </div>
</body>

</html>