<?php
$servername = "localhost";
$username = "root";
$passsword = "";
$db_name = "php_data";

$conn = mysqli_connect($servername, $username, $passsword, $db_name);
if ($conn) {
    // echo 'success';
} else {
    // echo 'false';
}



if (isset($_POST['submit'])) {


    $name = mysqli_real_escape_string($conn, $_POST['u_name']);
    $phone = mysqli_real_escape_string($conn, $_POST['u_phone']);
    $email = mysqli_real_escape_string($conn, $_POST['u_email']);
    $subject = mysqli_real_escape_string($conn, $_POST['u_subject']);
    $msg = mysqli_real_escape_string($conn, $_POST['u_msg']);


    if ($name == '' || $phone == '' || $email == '' || $subject == '' || $msg == '') {
        echo 'All field is required';
    } else {
        $insert_data = "INSERT INTO `employee`(`u_name`, `u_phone`, `u_email`, `u_subject`, `u_message`)
     VALUES ('$name','$phone','$email','$subject','$msg')";

        $result = mysqli_query($conn, $insert_data);

        if ($result) {
            echo 'Data Inserted Success';
        } else {
            echo 'Query Error';
        }
    }
} elseif (isset($_POST['update_data'])) {
    $editid = mysqli_real_escape_string($conn, $_POST['editid']);
    $name = mysqli_real_escape_string($conn, $_POST['u_name']);
    $phone = mysqli_real_escape_string($conn, $_POST['u_phone']);
    $email = mysqli_real_escape_string($conn, $_POST['u_email']);
    $subject = mysqli_real_escape_string($conn, $_POST['u_subject']);
    $msg = mysqli_real_escape_string($conn, $_POST['u_msg']);


    $update_data = "UPDATE `employee` SET `u_name`='$name',`u_phone`='$phone',`u_email`='$email',`u_subject`='$subject',`u_message`='$msg' WHERE id = '$editid'";
    $result = mysqli_query($conn, $update_data);

    if ($result) {
        echo 'Data Updated Success';
    } else {
        echo 'Query Error';
    }
} elseif (isset($_GET['ids'])) {
    $delete_id = $_GET['ids'];
    // echo $delete_id;
    $delete_data = "DELETE FROM `employee` WHERE id = '$delete_id'";
    $result = mysqli_query($conn, $delete_data);

    if ($result) {
        echo 'Data Delete Success';
    } else {
        echo 'Query Error';
    }
}
