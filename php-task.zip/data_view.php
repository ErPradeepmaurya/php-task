<?php
$servername = "localhost";
$username = "root";
$passsword = "";
$db_name = "php_data";

$conn = mysqli_connect($servername, $username, $passsword, $db_name);
if ($conn) {
    // echo 'success';
} else {
    // echo 'false';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Data</title>
</head>

<body>

    <a href="home.php" class="href" style="font-size:larger; font-weight:bold; margin:15%;">Add New Data</a>
    <table border="2">
        <thead>
            <th>Name</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Subject</th>
            <th>Message</th>
            <th>Edit</th>
            <th>Delete</th>
        </thead>
        <tbody>
            <?php
            $query = mysqli_query($conn, "SELECT * FROM `employee`");
            if (mysqli_num_rows($query) > 0)
                while ($data = mysqli_fetch_assoc($query)) {
            ?>
                <tr>
                    <td><?= $data['u_name'] ?></td>
                    <td><?= $data['u_phone'] ?></td>
                    <td><?= $data['u_email'] ?></td>
                    <td><?= $data['u_subject'] ?></td>
                    <td><?= $data['u_message'] ?></td>
                    <td><a href="edit.php?ids=<?= $data['id'] ?>">Edit</a></td>
                    <td><a href="save_data.php?ids=<?= $data['id'] ?>">Delete</a></td>

                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>

</html>